package com.account.rxvolley.base;

public interface BaseMvpView {
    void showProgress(String msg);
    void hideProgress();
}
